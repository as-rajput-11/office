from flask import Flask, render_template, request, jsonify
import random, math, psycopg2
import datetime
import itertools
conn = psycopg2.connect(host='127.0.0.1', dbname= "postgres", user= "postgres", password= "postgres")
app = Flask(__name__)

@app.route('/')
def index():
    train_details = []
    cur = conn.cursor()
    
    try:
        
        postgres_select_query = "select \"nominal_odc\",\"entraning_station\",\"detraining_station\",\"consignment\",\"type\" from \"mst_select\" ORDER BY \"sr_no\" DESC"
        cur.execute(postgres_select_query)
    except Exception as e:
        print(e)    
    rows = cur.fetchall()
    cur.close()
    for r in rows:
        train_details.append({"nominal_odc" : r[0],"entraning_station" : r[1],"detraining_station" : r[2],"consignment" : r[3],"type" : r[4]})
    return render_template('index.html',train_details=train_details)

@app.route('/data_save')
def data_save():
    train_id = request.args.get('train_id')
    print(train_id,'>>>>>>>>>>>>>>>>>')
    nominal_odc = request.args.get('nominal_odc')
    entraning_station = request.args.get('entraning_station')
    start_time = request.args.get('start_time')
    print(start_time)
    detraining_station = request.args.get('detraining_station')
    consignment = request.args.get('consignment')
    type1 = request.args.get('type')
    cur = conn.cursor()
    if train_id == '0':
        try: 
            cur.execute(f"insert into trains (nominal_odc, entraning_station, start_time,detraining_station,consignment,type) values ('{nominal_odc}', '{entraning_station}', '{start_time}', '{detraining_station}', '{consignment}','{type1}')")
        except:
            pass
    else:
        try: 
            cur.execute(f"update trains set nominal_odc = '{nominal_odc}', entraning_station = '{entraning_station}', start_time = '{start_time}', detraining_station = '{detraining_station}', consignment = '{consignment}', type = '{type1}' where train_id = {train_id}")
        except:
            pass     
    conn.commit()
    res = cur.rowcount
    cur.close()
    if res == 0:
        return 'An Error Occured'
    else:
        return 'Data Saved Successfully'

@app.route('/traindetails')
def do_detail():
    train_detail = []
    cur = conn.cursor()
    try:
        cur.execute('select train_id, nominal_odc, entraning_station, start_time, detraining_station, consignment, type from trains order by train_id')
    except Exception as e:
        print(e)
    rows = cur.fetchall()
    cur.close()
    for r in rows:
        start_time = r[3].strftime('%d/%m/%Y %H:%M:%S')
        train_detail.append({"train_id": r[0], "nominal_odc": r[1], "entraning_station" : r[2], "start_time" : start_time, "detraining_station" : r[4], "consignment" : r[5], "type" : r[6]})
    return jsonify(train_detail)

@app.route('/reports')
def do_report():
    list1 = ''
    list2 = ''
    lt=[]
    kl=[]
    subtracted = list()
    cur = conn.cursor()
    cur.execute("select ids from (select array_agg(train_id) as ids, d_capacity from train_rpt group by detraining_station, d_capacity) a where array_length(ids, 1) - d_capacity > 0")
    rows = cur.fetchall()
    for r in rows:
        cur.execute('select train_id,arrival_time,d_capacity,detraining_station,priority  from train_rpt where train_id in (' + ','.join(map(str, r[0])) + ') order by arrival_time')
        data = cur.fetchall()
        last_time = r,data[-1]
        lt.append(last_time)
        capacity=data[0][2]
        capacity_train_stop =[]
        capacity_train_on =[]
        cou = 0
        for index,i in enumerate(data):
            list1 = datetime.datetime.strptime(str(i[1]).split('.')[0],'%Y-%m-%d %H:%M:%S')
            capacity_train_stop.append(list1)
            if index >= capacity:
                list2 = datetime.datetime.strptime(str(i[1]).split('.')[0],'%Y-%m-%d %H:%M:%S')
                capacity_train_on.append(list2)
                co =capacity_train_on[cou]-capacity_train_stop[cou] < datetime.timedelta(hours=10)
                cou +=1
                if co == True:
                    kl.append(i)



        for r in kl:
            print(r)


        # Sorting the late trains according to priority 
        sorted_list = sorted(
            kl, key=lambda t: (t[4],t[1])
        )





    print(lt)
    late_train=[]
    timingchange =[]  
    for neartostation in sorted_list:
        cur.execute("select * from mst_distance where src = '"+str(neartostation[3])+"' and dist < 20 order by dist")
        near_station = cur.fetchall()
        print(near_station,"++++++++++++++++++++++++++++===================")
        if near_station == []:
            timingchange.append(neartostation)
        else:
            while near_station :
                cur.execute("select detraining_station,d_capacity,arrival_time from train_rpt where detraining_station = '"+str(near_station[0][1])+"'")
                station0 = cur.fetchall()
                countp = len(station0)
                if station0[0][1] > countp:
                    cur.execute("update trains set detraining_station ='"+str(station0[0][0])+"' where train_id="+str(neartostation[0])+" ")
                    conn.commit()
                    near_station.clear()
                else:
                    if len(near_station ) <= 1:
                        timingchange.append(neartostation)
                    near_station.pop(0)
   

    for key, delay_time_list in itertools.groupby(timingchange, lambda x: x[3]):
        # Priority Logic
        delay_time_list = list(delay_time_list)
        cur.execute("select  train_id,arrival_time +interval'10 hour ' as addtime ,detraining_station,priority,d_capacity from train_rpt where detraining_station = '"+str(key)+"' order by arrival_time ")
        data5 = cur.fetchall()
        delt = []
        cap = data5[0][4]         
        for i in range(cap):
            time_dif = data5[i][1]-delay_time_list[i][1]
            delt.append(delay_time_list[i])
            [data5.remove(j) for j in data5 if j[0] == delay_time_list[i][0]]
            data5[i] = delay_time_list[i]
            cur.execute("update trains set start_time = start_time +interval'"+str(time_dif)+"' where train_id= "+str(delay_time_list[i][0])+"")
            conn.commit()
           

        cur.execute("select  train_id,arrival_time +interval'10 hour ' as addtime ,detraining_station,priority,d_capacity from train_rpt where detraining_station = '"+str(key)+"' order by arrival_time ")
        data6 = cur.fetchall()


        for i in delt:
            for j in delay_time_list:
                if i[0] == j[0]:
                    delay_time_list.remove(j)
                    
        for i in range(len(delay_time_list)):
            res=[]
            for j in data5:
                for k in data6:
                    if j[0]==k[0]:
                        res.append(k)
            time_dif = res[i][1]-delay_time_list[i][1]
            cur.execute("update trains set start_time = start_time +interval'"+str(time_dif)+"' where train_id= "+str(delay_time_list[i][0])+"")
            conn.commit()
            
            
            # if data5[item][0]==delay_time_list[item][0]:
                # time_dif = data5[0][1]-delay_time_list[item][1]
                # print('jjj')
            # else:
            # for i in data5:
            #     if i[0] == delay_time_list[item][0]:
            #         data5.remove(i)
            # if len(data5)-1<item:
            #     data5.append(delay_time_list[item])
            # else:
            #     data5[item]=delay_time_list[item]
            # print(item,len(data5),len(delay_time_list))
            # rs=[]
            # dl=[]
            # for i in data5:
            #     x=list(i)
            #     rs.append(x)
            # data5=[]
            # for i in rs:
            #     data5.append(i)
            # for i in delay_time_list:
            #     x=list(i)
            #     dl.append(x)
            # delay_time_list=[]
            # for i in dl:
            #     delay_time_list.append(i)



            # data5.pop(0)
            # data5.pop(item)
            # print(data4[item][1])
            # if data5[item][0] == delay_time_list[item-1][0]:
            #     del data5[item:]
            #     for i in delay_time_list:
            #         data5.append(i)
            # for i in delay_time_list:
            #     print("Train-id: ",i[0])
            #     print("Arrival-time: ",i[1])
            #     print("Loading Time: ",i[4])
            # print('')
            # time_dif = rs[item][1]-delay_time_list[item][1]
            # if rs[item][0]==dl[item][0]:
            #     time_dif=rs[0][1]-dl[item][1]
            #     print('rrr')
            # else:
            # time_dif=0
            # 
            # time_dif=0
            # if data5[item][0]==delay_time_list[item][0]:
            #     time_dif=data5[0][1]-delay_time_list[item][1]
            # else:
            # if data5[item][0]==delay_time_list[item][0]:
            #     time_dif=data5[0][1]-delay_time_list[item][1]
            #     print('jjj')
            # else:
            # rs[item]=list(delay_time_list[item])
            # time_dif = data5[item][1]-delay_time_list[item][1]
            # data5.pop(z)
            # z+=1

            # +str(delay_time_list[item][0])+
            # cur.execute("update trains set start_time = start_time +interval'"+str(time_dif)+"' where train_id= "+str(delay_time_list[item][0])+"")
            # conn.commit()
          
        # delay_time_list.pop(0)
    report_detail = []
    cur = conn.cursor()
    try:
        cur.execute('select train_id, nominal_odc, type, entraning_station, start_time, detraining_station, consignment, speed, d_capacity, priority, distance, arrival_time, travel_time, loading_time from train_rpt order by train_id')
    except Exception as e:
        print(e)
    rows = cur.fetchall()
    cur.close()
    for r in rows:
        start_time = r[4].strftime('%d/%m/%Y %H:%M:%S')
        arrival_time = r[11].strftime('%d/%m/%Y %H:%M:%S')
        travel_time = str(r[12]).split('000')[0]
        loading_time = r[13].strftime('%d/%m/%Y %H:%M:%S')
        report_detail.append({"train_id": r[0],"nominal_odc": r[1],"type": r[2],"entraning_station": r[3],"start_time": start_time,"detraining_station": r[5],"consignment": r[6], "speed": r[7], "d_capacity" : r[8], "priority" : r[9], "distance" : r[10], "arrival_time" : arrival_time,"travel_time" : travel_time, "loading_time" : loading_time})
    return jsonify(report_detail)

@app.route('/report')
def do_reports():
    return render_template('reports.html')

@app.route('/checks')
def do_check():
    list1 = ''
    list2 = ''
    lt=[]
    kl=[]
    subtracted = list()
    cur = conn.cursor()
    cur.execute("DELETE FROM mst_check_late_train_details")
    cur.execute("select ids from (select array_agg(train_id) as ids, d_capacity from train_rpt group by detraining_station, d_capacity) a where array_length(ids, 1) - d_capacity > 0")
    rows = cur.fetchall()
    for r in rows:
        cur.execute('select train_id,arrival_time,d_capacity,detraining_station,loading_time,start_time ,priority from train_rpt where train_id in (' + ','.join(map(str, r[0])) + ') order by arrival_time')
        data = cur.fetchall()
        last_time = r,data[-1]
        lt.append(last_time)
        capacity=data[0][2]
        capacity_train_stop =[]
        capacity_train_on =[]
        cou = 0
        for index,i in enumerate(data):
            list1 = datetime.datetime.strptime(str(i[1]).split('.')[0],'%Y-%m-%d %H:%M:%S')
            capacity_train_stop.append(list1)
            if index >= capacity:
                list2 = datetime.datetime.strptime(str(i[1]).split('.')[0],'%Y-%m-%d %H:%M:%S')
                capacity_train_on.append(list2)
                co =capacity_train_on[cou]-capacity_train_stop[cou] < datetime.timedelta(hours=10)
                cou +=1
                if co == True:
                    kl.append(i)

    
    late_train=[]
    for check_late_train in kl:
        cur.execute(f"insert into mst_check_late_train_details(train_id,detraining_station,d_capacity,arrival_time,loading_time,start_time,priority) values("+str(check_late_train[0])+",'"+str(check_late_train[3])+"',"+str(check_late_train[2])+",'"+str(check_late_train[1])+"','"+str(check_late_train[4])+"','"+str(check_late_train[5])+"',"+str(check_late_train[6])+")")
        conn.commit()
        
    cur = conn.cursor()
    train_check_detail = []
    try:
        cur.execute('select train_id, detraining_station, d_capacity, start_time, arrival_time, loading_time,priority from mst_check_late_train_details order by train_id')
    except Exception as e:
        print(e)
    rows = cur.fetchall()
    cur.close()
    for r in rows:
        start_time = r[3].strftime('%d/%m/%Y %H:%M:%S')
        arrival_time = r[4].strftime('%d/%m/%Y %H:%M:%S')
        loading_time = r[5].strftime('%d/%m/%Y %H:%M:%S')
        train_check_detail.append({"train_id": r[0],"detraining_station": r[1],"d_capacity": r[2],"start_time": start_time,"arrival_time": arrival_time,"loading_time": loading_time,"priority":r[6]})
    return jsonify(train_check_detail)

@app.route('/check')
def do_checks():
    return render_template('train_check.html')

@app.route('/cluster')
def do_cluster():
    return render_template('cluster.html')

if __name__ == '__main__':
    app.run(host= "0.0.0.0", debug= True, port=5000)
    



