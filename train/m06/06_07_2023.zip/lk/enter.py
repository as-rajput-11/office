import psycopg2
# import datetime
# import time
# import itertools
from colorama import Fore, Back, Style 
# from termcolor import colored,cprint

conn = psycopg2.connect(
    database="postgres",
    user='postgres',
    password='postgres',
    host='localhost',
    port='5432'
)


cur = conn.cursor()
cur.execute("select * from trains where entraning_station = 'MIRAJ'")
f = cur.fetchall()
print(f)

cur.execute("select capacity from mst_capacity where station= '"+f[0][2]+"'")
g =cur.fetchall()
print(g)

cur.execute("select entraning_station from train_rpt where entraning_station = '"+f[0][2]+"' and start_time ='"+str(f[0][3])+"'")
d =cur.fetchall()

print(len(d))

cur.execute("select detraining_station from train_rpt where detraining_station ='"+f[0][2]+"' and arrival_time between '"+str(f[0][3])+"' and '"+str(f[0][3])+"'::timestamp + INTERVAL '10 hours'")
k =cur.fetchall()
print(len(k+d))
if int(g[0][0])>len(k+d):
    cur.execute(f"insert into trains(nominal_odc, entraning_station, start_time, detraining_station, consignment, type)values ('{f[0][1]}',' {f[0][2]}', '{f[0][3]}', '{f[0][4]}', '{f[0][5]}', '{f[0][6]}')")
    conn.commit()
else:
    cur.execute("select dest from mst_distance where src = '"+f[0][2]+"' and dist < 200 order by dist")
    l =cur.fetchall()
    l = [item[0] for item in l if item[0] != f[0][4]]
    print(l[0],"_______________")
    

    cur.execute("truncate table mst_enter_time")
    conn.commit()
    check_cap = True
    while check_cap:
        
        if l == []:
            cur.execute("select dest from mst_distance where src = '"+f[0][2]+"' and dist < 200 order by dist")
            padh =cur.fetchall()
            new = [item[0] for item in padh if item[0] != f[0][4]]
            print(new,"==========================+_________________") 
            for check_time in new:
                cur.execute("select entraning_station,start_time from train_rpt where entraning_station ='"+str(check_time)+"' and start_time between '"+str(f[0][3])+"' and '"+str(f[0][3])+"'::timestamp + INTERVAL '10 hours' order by start_time")
                train_time =cur.fetchall()
                print(train_time[0][1],"__________________")
                cur.execute(f"insert into mst_enter_time(station,time)values ('{train_time[0][0]}','{train_time[0][1]}')")
                conn.commit()

                
                
                
            cur.execute("select * from mst_enter_time order by time")
            ertimeupadte=cur.fetchall()
            cur.execute("select capacity from mst_capacity where station= '"+ertimeupadte[0][1]+"'")
            captyy =cur.fetchall()
           
            cur.execute("select * from trains where entraning_station = '"+str(ertimeupadte[0][1])+"' order by start_time desc limit "+str(captyy[0][0])) 
            upat = cur.fetchall()
            
            
            li = -1
            cur.execute(f"insert into trains(nominal_odc, entraning_station, start_time, detraining_station, consignment, type)values ('{f[0][1]}','{upat[li][2]}', '{upat[li][3]}'::timestamp + INTERVAL '10 hours', '{f[0][4]}', '{f[0][5]}', '{f[0][6]}')")
            conn.commit()
            print(upat,"++++++++++++++++++++++++++=============")
            
            # print(f"insert into trains(nominal_odc, entraning_station, start_time, detraining_station, consignment, type)values ('{f[0][1]}','{ertimeupadte[0][1]}', '{ertimeupadte[0][2]}''::timestamp + INTERVAL '10 hours' order by start_time', '{f[0][4]}', '{f[0][5]}', '{f[0][6]}')")    
            check_cap = False
  
        
        else: 
        # timeforstation.append(train_time[0])
                
        # print(timeforstation)
            cur.execute("select capacity from mst_capacity where station= '"+l[0]+"'")
            z =cur.fetchall()
            print(z[0][0])
            print(l[0][0],"===============================================")    
            cur.execute("select entraning_station from train_rpt where entraning_station = '"+l[0]+"' and start_time ='"+str(f[0][3])+"'")
            op =cur.fetchall()
            print(op)

            cur.execute("select detraining_station from train_rpt where detraining_station ='"+l[0]+"' and arrival_time between '"+str(f[0][3])+"' and '"+str(f[0][3])+"'::timestamp + INTERVAL '10 hours'")
            c =cur.fetchall()
            print(c)
            
            print(len(op+c),z[0][0],"5466546464646")
            if int(z[0][0])>len(op+c):
                
                cur.execute(f"insert into trains(nominal_odc, entraning_station, start_time, detraining_station, consignment, type)values ('{f[0][1]}','{l[0]}', '{f[0][3]}', '{f[0][4]}', '{f[0][5]}', '{f[0][6]}')")
                conn.commit()
                check_cap = False
            else:
                l.pop(0)