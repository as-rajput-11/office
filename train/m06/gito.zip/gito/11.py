import psycopg2
import datetime
import time
import itertools
import math

conn = psycopg2.connect(
    database="delete",
    user='postgres',
    password='postgres',
    host='localhost',
    port='5432'
)

cursor = conn.cursor()

types = ['P','Q','R']

# Getting data of extra train of P type


for type in range(len(types)): 
    # cursor.execute("select * from train_rpt1 where type = 'P' order by d_loading_hour desc limit 7")
    
    if str(types[type]) == 'P':
        cursor.execute("select * from train_rpt1 where type = 'P' order by d_loading_hour desc limit 7")
        # cursor.execute("select * from train_rpt1 where type = '"+str(types[type])+"' order by d_loading_hour offset 20")
        row = cursor.fetchall()
    
    if str(types[type]) == 'Q':
        cursor.execute("select * from train_rpt1 where type = '"+str(types[type])+"' order by d_loading_hour offset 20")
        row = cursor.fetchall()

    if str(types[type]) == 'R':
        cursor.execute("select * from train_rpt1 where type = '"+str(types[type])+"' order by d_loading_hour offset 20")
        row = cursor.fetchall()

    for i in row:
        print(i,'roqqqqqqqqqqqqqqqqqqqq')
        print()
    if row == []:
        continue
    # for i in row:
    #     print(i)

        # train_id int,
        # nominal_odc varchar,
        # type varchar,
        # entraning_station varchar,
        # place timestamp without time zone,
        # place_hours int,
        # loading_hours int,
        # start_hours int,
        # m_day text,
        # start_time timestamp without time zone,
        # detraining_station varchar,
        # consignment varchar,
        # speed int,
        # d_capacity int,
        # priority smallint,
        # distance double precision,
        # arrival_hours int,
        # arriv_days text,
        # arriv_day int,
        # arrival_time timestamp without time zone,
        # travel_hour interval,
        # travel_time interval,
        # loading_hour int,
        # d_loading_time timestamp without time zone,
        # delay_time timestamp without time zone

    cursor.execute("INSERT INTO recycle (train_id, nominal_odc, type, entraning_station, place, place_hours, loading_hours, start_hours, m_day, start_time, detraining_station, consignment, speed, d_capacity, priority, distance, arrival_hours, arriv_days, arriv_day, arrival_time, travel_hour, travel_time, loading_hour, d_loading_time) SELECT train_id, nominal_odc, type, entraning_station, place, place_hours, e_loading_hours, start_hours, m_day, start_time, detraining_station, consignment, speed, d_capacity, priority, distance, arrival_hours, arriv_days, arriv_day, arrival_time, travel_hour, travel_time, d_loading_hour, d_loading_time FROM train_rpt1 WHERE type = '"+row[0][2]+"' ORDER BY arrival_hours offset 20 ")

    conn.commit()

    recycled = []
    for index in range(len(row)):
        # for i in row:
            # print(i[24])

            # cursor.execute(f"insert into recycle(train_id, nominal_odc, type, entraning_station, place, place_hours, loading_hours, start_hours, m_day, start_time, detraining_station, consignment, speed, d_capacity, priority, distance, arrival_hours, arriv_days, arriv_day, arrival_time, travel_hour, travel_time, loading_hour, d_loading_time)values ('{row[index][0]}','{row[index][1]}', '{row[index][2]}', '{row[index][3]}', '{row[index][4]}', '{row[index][5]}', '{row[index][6]}', '{row[index][7]}', '{row[index][8]}', '{row[index][9]}', '{row[index][10]}', '{row[index][11]}', '{row[index][12]}', '{row[index][13]}', '{row[index][14]}', '{row[index][15]}', '{row[index][16]}', '{row[index][17]}', '{row[index][18]}', '{row[index][19]}', '{row[index][20]}', '{row[index][21]}', '{row[index][22]}', '{row[index][23]}')")
            # conn.commit()


            

            # cursor.execute("INSERT INTO mst_recycling_trains (train_id,start_hours,detraining_station, arrival_time ,d_loading_time,type,arrival_hours,d_loading_hours,consignment) SELECT train_id,start_hours,detraining_station, arrival_time ,d_loading_time,type,arrival_hours,d_loading_hour,consignment FROM train_rpt1 WHERE type = 'P' ORDER BY arrival_hours offset 20 ")

            

            # Getting the remaning trains of P type
            # cursor.execute("select * from train_rpt1 where type = 'P' order by loading_hour limit 20")
            cursor.execute("select * from train_rpt1 where type = '"+row[0][2]+"' order by d_loading_hour limit 20")
            trains = cursor.fetchall()
            # 3, 10
            for i in trains:
                print(i,"oooooooooooooooooooooooooo")
            # for i in trains:
            #     print(i)
            #     print()
            li=[]

            
            # Finding the distance between the remaning train and the destination station of the extra train 
            for j in trains:
                if str(j[3]) == str(row[index][3]):
                    continue
                cursor.execute("select * from mst_distance where src = '"+str(j[3])+"' and dest = '"+str(row[index][3])+"'")
                r = cursor.fetchall()
                # if r == []:
                #     break
                print(j[3])
                print(row[index][3])
                print(r[0])
                x = []
                x.append(r[0])
                x.append(j[0])
                li.append(x)
            # li = set(li)
            # li=list(li)
            print("===================>:")
            print('')
            for i in li:
                print(i)

    # li.sort()
    # sorted_list = sorted(
    #         li, key = lambda t: t[2]
    # )
    # print()
    # print("List with minimum time between stations:")
    # print('')
    # for i in sorted_list:
    #     print(i)




            x=[]

            # Getting the speed of the remaning trains
            for i in li:
                cursor.execute("select speed from train_rpt1 where train_id = '"+str(i[1])+"'")
                speed = cursor.fetchall()
                l=[]
                l.append(i[0])
                l.append(i[1])
                l.append(speed[0][0])
                x.append(l)

            print('')

            # Getting time by formula time = distance/speed
            for i in x:
                t = round(i[0][2]/i[2],2)
                i.append(t)

            for i in x:
                print(i)

            # cursor.execute("select train_id, entraning_station, speed, d_loading_time from train_rpt1 order by loading_hour limit 20")
            cursor.execute("select train_id, entraning_station, speed, d_loading_time from train_rpt1 where type = '"+row[0][2]+"' order by d_loading_hour limit 20")
            fin = cursor.fetchall()

            print('')

            for i in fin:
                print(i,"++++++++++++++++++++")
            print('')

            # Adding that time in loading hours
            z=[]
            for i in fin:
                for j in x:
                    if j[1] == i[0]:
                        print(j[3],'hoursssssssssssssssssssssss')
                        delta = datetime.timedelta(hours=j[3])
                        s = i[3]+delta
                        y=[]
                        y.append(j[1])
                        y.append(s)
                        z.append(y)
                        # print(j[1],i[0])
                        
            for i in z:
                print(i)

            # Sorting the remaning trains acoording to the minimum loading hours 
            z_sorted_list = sorted(
                    z, key = lambda t: t[1]
            )

            print('')
            for i in z_sorted_list:
                print(i,'zzzzzzzzzzzzzzzzzzzzzzzzzzz')

            final_replace = []

            print()
            print(index)
            # print(z_sorted_list[0][0])
            # for i in range(len(row)):
            
            for i in range(len(recycled)):
                for j in z_sorted_list:
                    # print(j[0],recycled[i][0],'jjjjjjjjjjjjjjjjjjjjjj')
                    if recycled[i][0] == j[0]:
                        z_sorted_list.remove(j)

            for i in recycled:
                print(i)

            final_replace.append(z_sorted_list[0])
            recycled.append(final_replace[0])
            for i in final_replace:
                print(i)

            print()
            # for i in row:
            print(row[index],'ppppppppppppppppppp')

            row2 = []

            # for i in row:
            row2.append(list(row[index]))
            print()
            for i in row2:
                print(i)

            print(len(row2),'++++++++++++++++++++++++++++++++++')
            for i in range(len(row2)):
                # row2[i][0]=final_replace[i][0]
                # row2[i][4]=final_replace[i][1]

                # cursor.execute("Update recycle set train_id = '"+str(final_replace[i][0])+"', place = '"+str(final_replace[i][1])+"' where train_id = '"+str(row2[i][0])+"'")
                conn.commit()
            print()
            for i in row2:
                print(i)
