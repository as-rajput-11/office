import psycopg2
import datetime
import time
import itertools
import math

conn = psycopg2.connect(
    database="last_update",
    user='postgres',
    password='postgres',
    host='localhost',
    port='5432'
)

cur = conn.cursor()
cur.execute("TRUNCATE TABLE mst_recycling_trains")
cur.execute("INSERT INTO mst_recycling_trains (train_id,start_hours,detraining_station, arrival_time ,d_loading_time,type,arrival_hours,d_loading_hours,consignment) SELECT train_id,start_hours,detraining_station, arrival_time ,d_loading_time,type,arrival_hours,d_loading_hour,consignment FROM train_rpt1 WHERE type = 'P' ORDER BY arrival_hours offset 20 ")
conn.commit()
# initial_time =[]
# recycle_time =[]

# cur.execute("select train_id,detraining_station,d_loading_time,type from train_rpt1 order by arrival_time limit 20")
# initial_tim = cur.fetchall()
# for ini in initial_tim:
#     initial_time.append(ini)
#     # print("list2",ini)

# cur.execute("select * from mst_recycling_trains order by arrival_time")
# recycle_tim=cur.fetchall()
# for po in recycle_tim:
#     recycle_time.append(po)

# # print(recycle_time)
# for rec in recycle_tim:

#     cur.execute("select train_id,detraining_station,d_loading_time,type from train_rpt1 order by arrival_time limit 20 ")
#     datae = cur.fetchall()
#     for ini1 in datae:
       
#         cur.execute("select * from mst_distance where src ='"+str(ini1[1])+"' and dest ='"+str(rec[1])+"'")
#         hjkl=cur.fetchall()
#         print(hjkl)   
   

        


cur.execute("select train_id,detraining_station,d_loading_time,type from train_rpt1 order by arrival_time limit 20")
av= cur.fetchall()

cur.execute("select * from mst_recycling_trains order by arrival_time")
rc = cur.fetchall()
# print(rc)
for check in rc:
 
    min_datetime_b = min(av, key=lambda x: x[2])  # Find minimum datetime value in list b
        
    av.remove(min_datetime_b) 
    print(av)
    # print("=====================")
    # for avail in av:
    #     print(avail,"==")











# import datetime
# a = [(1, 'KOLHAPUR', datetime.datetime(2024, 1, 2, 1, 34, 12), datetime.datetime(2024, 1, 2, 11, 34, 12), 'P', '8786', '8796', 'C', '8784'), (29, 'KOLHAPUR', datetime.datetime(2024, 1, 2, 1, 34, 12), datetime.datetime(2024, 1, 2, 11, 34, 12), 'P', '8786', '8796', 'C', '8784'), (30, 'KOLHAPUR', datetime.datetime(2024, 1, 2, 11, 34, 12), datetime.datetime(2024, 1, 2, 21, 34, 12), 'P', '8796', '8806', 'C', '8790'), (31, 'KOLHAPUR', datetime.datetime(2024, 1, 2, 11, 34, 12), datetime.datetime(2024, 1, 2, 21, 34, 12), 'P', '8796', '8806', 'C', '8790'), (32, 'KOLHAPUR', datetime.datetime(2024, 1, 2, 21, 34, 12), datetime.datetime(2024, 1, 3, 7, 34, 12), 'P', '8806', '8816', 'C', '8800')]                                                                                          
# b = [(10, 'TUNDLA', datetime.datetime(2023, 1, 2, 11, 8, 16, 800000), 'P'), (2, 'PRATAPGARH', datetime.datetime(2023, 1, 2, 11, 43, 57, 600000), 'P'), (15, 'JAUNPUR', datetime.datetime(2023, 1, 2, 12, 28, 22, 800000), 'P'), (11, 'TUNDLA', datetime.datetime(2023, 1, 2, 12, 36, 1, 200000), 'P'), (3, 'MIRZAPUR', datetime.datetime(2023, 1, 2, 15, 8, 29, 400000), 'P'), (12, 'MEERUT', datetime.datetime(2023, 1, 2, 17, 21, 40, 500000), 'P'), (8, 'KANPUR', datetime.datetime(2023, 1, 2, 19, 27, 13, 200000), 'P'), (14, 'SHAHJAHANPUR', datetime.datetime(2023, 1, 2, 21, 22, 12, 900000), 'P'), (4, 'FATEHPUR', datetime.datetime(2023, 1, 2, 21, 55, 58, 800000), 'P'), (17, 'FATEHPUR', datetime.datetime(2023, 1, 2, 22, 52, 53, 400000), 'P'), (6, 'BASTI', datetime.datetime(2023, 1, 2, 23, 20, 37, 500000), 'P'), (7, 'MIRZAPUR', datetime.datetime(2023, 1, 3, 0, 13, 26, 400000), 'P'), (13, 'DDU_JUNCTION', datetime.datetime(2023, 1, 3, 0, 40, 30), 'P'), (20, 'JAUNPUR', datetime.datetime(2023, 1, 3, 1, 2, 56, 400000), 'P'), (5, 'MIRZAPUR', datetime.datetime(2023, 1, 3, 1, 8, 29, 400000), 'P'), (21, 'DDU_JUNCTION', datetime.datetime(2023, 1, 3, 4, 8, 30, 600000), 'P'), (18, 'BASTI', datetime.datetime(2023, 1, 3, 6, 30, 9), 'P'), (16, 'VARANASI', datetime.datetime(2023, 1, 3, 6, 51, 54), 'P'), (19, 'MIRZAPUR', datetime.datetime(2023, 1, 3, 10, 13, 26, 400000), 'P'), (9, 'TUNDLA', datetime.datetime(2023, 1, 3, 14, 46, 4, 800000), 'P')]
# for tuple_a in a:
#     min_datetime_b = min(b, key=lambda x: x[2])  # Find minimum datetime value in list b
#     b.remove(min_datetime_b)  # Remove the minimum datetime tuple from list b
    
#     print(f"Found tuple_a={tuple_a}, min_datetime_b={min_datetime_b}")

# print("Updated lists after processing:")
# print("a =", a)
# print("b =", b)
