import psycopg2
import datetime
import time
import itertools
import math

conn = psycopg2.connect(
    database="28_7_2023",
    user='postgres',
    password='postgres',
    host='localhost',
    port='5432'
)

cursor = conn.cursor()

# Recycle logic
types = ['P','Q','R']

cursor.execute("DELETE FROM recycle")
cursor.execute("DELETE FROM recycle_trains")
cursor.execute("INSERT INTO recycle_trains (sr_no, nominal_odc, entraning_station, place, detraining_station, consignment, type, delay_time, e_loading, change_station, train_id, Ir) SELECT sr_no, nominal_odc, entraning_station, place, detraining_station, consignment, type, delay_time, e_loading, change_station, train_id, Ir FROM trains")
# Getting data of extra trains
for type in range(len(types)): 
    
    if str(types[type]) == 'P':
        cursor.execute("select * from train_rpt1 where type = '"+str(types[type])+"' order by loading_hour offset 20")
        row = cursor.fetchall()

        # Adding already recycled train in recycled
        recycled = []
        # cursor.execute("select train_id, place from recycle where type = '"+str(types[type])+"'")
        # re = cursor.fetchall()
        # for i in range(len(re)):
        #     x = []
        #     x.append(re[i][0])
        #     x.append(re[i][1])
        #     recycled.append(x)
    
    if str(types[type]) == 'Q':
        cursor.execute("select * from train_rpt1 where type = '"+str(types[type])+"' order by loading_hour offset 20")
        row = cursor.fetchall()

        # Adding already recycled train in recycled
        recycled = []
        # cursor.execute("select train_id, place from recycle where type = '"+str(types[type])+"'")
        # re = cursor.fetchall()
        # for i in range(len(re)):
        #     x = []
        #     x.append(re[i][0])
        #     x.append(re[i][1])
        #     recycled.append(x)

    if str(types[type]) == 'R':
        cursor.execute("select * from train_rpt1 where type = '"+str(types[type])+"' order by loading_hour offset 20")
        row = cursor.fetchall()

        # Adding already recycled train in recycled
        recycled = []
        # cursor.execute("select train_id, place from recycle where type = '"+str(types[type])+"'")
        # re = cursor.fetchall()
        # for i in range(len(re)):
        #     x = []
        #     x.append(re[i][0])
        #     x.append(re[i][1])
        #     recycled.append(x)

    if row == []:
        continue
 

    cursor.execute("INSERT INTO recycle (sr_no, train_id, nominal_odc, type, entraning_station, place, place_hours, loading_hours, start_hours, m_day, start_time, detraining_station, consignment, speed, d_capacity, priority, distance, arrival_hours, arriv_days, arriv_day, arrival_time, travel_hour, travel_time, loading_hour, d_loading_time) SELECT sr_no, train_id, nominal_odc, type, entraning_station, place, place_hours, loading_hours, start_hours, m_day, start_time, detraining_station, consignment, speed, d_capacity, priority, distance, arrival_hours, arriv_days, arriv_day, arrival_time, travel_hour, travel_time, loading_hour, d_loading_time FROM train_rpt1 WHERE type = '"+row[0][3]+"' ORDER BY arrival_hours offset 20 ")

    conn.commit()


    for index in range(len(row)):

            cursor.execute("select * from train_rpt1 where type = '"+row[0][3]+"' order by loading_hour limit 20")
            trains = cursor.fetchall()
    
            li=[]
            # Finding the distance between the detraning station of remaning trains and the entraning station of the extra train 
            for j in trains:
                if str(j[11]) == str(row[index][4]):
                    continue
                cursor.execute("select * from mst_distance where src = '"+str(j[11])+"' and dest = '"+str(row[index][4])+"'")
                r = cursor.fetchall()
                x = []
                x.append(r[0])
                x.append(j[0])
                li.append(x)


            x=[]
         
            # Getting the speed of the remaning trains
            for i in li:
                # cursor.execute("select speed from train_rpt1 where sr_no = '"+str(i[1])+"'")
                cursor.execute("select type from train_rpt1 where sr_no = '"+str(i[1])+"'")
                type = cursor.fetchall()
                cursor.execute("select speed from mst_speed where odc = 'D' and type = '"+str(type[0][0])+"'")
                speed = cursor.fetchall()
                l=[]
                l.append(i[0])
                l.append(i[1])
                l.append(speed[0][0])
                x.append(l)


            # Getting time by formula time = distance/speed
            for i in x:
                t = round(i[0][2]/i[2],2)
                i.append(t)


            cursor.execute("select train_id, detraining_station, speed, d_loading_time, sr_no from train_rpt1 where type = '"+row[0][3]+"' order by loading_hour limit 20")
            fin = cursor.fetchall()

            # Adding that time in loading hours
            z=[]
            for i in fin:
                for j in x:
                    if j[1] == i[4]:
                        delta = datetime.timedelta(hours=j[3])
                        s = i[3]+delta
                        y=[]
                        y.append(j[1])
                        y.append(s)
                        z.append(y)


            # Sorting the remaning trains acoording to the minimum loading hours 
            z_sorted_list = sorted(
                    z, key = lambda t: t[1]
            )

            final_replace = []
            [z_sorted_list.remove(j) for i in range(len(recycled)) for j in z_sorted_list if recycled[i][0] == j[0]]
                
            final_replace.append(z_sorted_list[0])
            recycled.append(final_replace[0])

            row2 = []
            row2.append(list(row[index]))

            [cursor.execute("Update recycle set train_id = '"+str(final_replace[i][0])+"', Ir = 'R', place = '"+str(final_replace[i][1])+"' where sr_no = '"+str(row2[i][0])+"'") for i in range(len(row2))]
            
            conn.commit()


    # Updating extra trains id and place time in recycle_trains table:
    cursor.execute("select sr_no, train_id, ir, place from recycle")
    rc = cursor.fetchall()
    for i in range(len(rc)):
        cursor.execute("Update recycle_trains set train_id = '"+str(rc[i][1])+"', Ir = '"+str(rc[i][2])+"', place = '"+str(rc[i][3])+"' where sr_no = '"+str(rc[i][0])+"'")
        conn.commit()

            


# creating a another table ==>

# -- CREATE TABLE recycle_trains (
# -- 	sr_no int primary key,
# -- 	nominal_odc varchar,
# -- 	entraning_station varchar,
# -- 	place timestamp without time zone,
# -- 	detraining_station varchar,
# -- 	consignment varchar,
# -- 	type varchar,
# -- 	delay_time timestamp without time zone,
# -- 	e_loading timestamp without time zone,
# -- 	data0 timestamp without time zone,
# -- 	change_station varchar,
# --     train_id int,
# -- 	IR varchar
# -- );


# -- INSERT INTO recycle_trains (sr_no, nominal_odc, entraning_station, place, detraining_station, consignment, type, delay_time, e_loading, change_station, train_id, Ir) SELECT sr_no, nominal_odc, entraning_station, place, detraining_station, consignment, type, delay_time, e_loading, change_station, train_id, Ir FROM trains;