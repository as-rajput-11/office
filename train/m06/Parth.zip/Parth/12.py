import psycopg2
import datetime
import time
import itertools
import math

conn = psycopg2.connect(
    database="28_7_2023",
    user='postgres',
    password='postgres',
    host='localhost',
    port='5432'
)

cursor = conn.cursor()

# Recycle logic
types = ['P','Q','R']

# Getting data of extra trains
for type in range(len(types)): 
    
    if str(types[type]) == 'P':
        cursor.execute("select * from train_rpt1 where type = '"+str(types[type])+"' order by loading_hour offset 20")
        row = cursor.fetchall()
    
    if str(types[type]) == 'Q':
        cursor.execute("select * from train_rpt1 where type = '"+str(types[type])+"' order by loading_hour offset 20")
        row = cursor.fetchall()

    if str(types[type]) == 'R':
        cursor.execute("select * from train_rpt1 where type = '"+str(types[type])+"' order by loading_hour offset 20")
        row = cursor.fetchall()

    if row == []:
        continue
 

    cursor.execute("INSERT INTO recycle (train_id, nominal_odc, type, entraning_station, place, place_hours, loading_hours, start_hours, m_day, start_time, detraining_station, consignment, speed, d_capacity, priority, distance, arrival_hours, arriv_days, arriv_day, arrival_time, travel_hour, travel_time, loading_hour, d_loading_time) SELECT train_id, nominal_odc, type, entraning_station, place, place_hours, loading_hours, start_hours, m_day, start_time, detraining_station, consignment, speed, d_capacity, priority, distance, arrival_hours, arriv_days, arriv_day, arrival_time, travel_hour, travel_time, loading_hour, d_loading_time FROM train_rpt1 WHERE type = '"+row[0][2]+"' ORDER BY arrival_hours offset 20 ")

    conn.commit()

    recycled = []
    for index in range(len(row)):

            cursor.execute("select * from train_rpt1 where type = '"+row[0][2]+"' order by loading_hour limit 20")
            trains = cursor.fetchall()
    
            li=[]
            # Finding the distance between the detraning station of remaning trains and the entraning station of the extra train 
            for j in trains:
                if str(j[10]) == str(row[index][3]):
                    continue
                cursor.execute("select * from mst_distance where src = '"+str(j[10])+"' and dest = '"+str(row[index][3])+"'")
                r = cursor.fetchall()
                x = []
                x.append(r[0])
                x.append(j[0])
                li.append(x)


            x=[]
            # Getting the speed of the remaning trains
            for i in li:
                cursor.execute("select speed from train_rpt1 where train_id = '"+str(i[1])+"'")
                speed = cursor.fetchall()
                l=[]
                l.append(i[0])
                l.append(i[1])
                l.append(speed[0][0])
                x.append(l)

            # Getting time by formula time = distance/speed
            for i in x:
                t = round(i[0][2]/i[2],2)
                i.append(t)


            cursor.execute("select train_id, detraining_station, speed, d_loading_time from train_rpt1 where type = '"+row[0][2]+"' order by loading_hour limit 20")
            fin = cursor.fetchall()

            # Adding that time in loading hours
            z=[]
            for i in fin:
                for j in x:
                    if j[1] == i[0]:
                        delta = datetime.timedelta(hours=j[3])
                        s = i[3]+delta
                        y=[]
                        y.append(j[1])
                        y.append(s)
                        z.append(y)


            # Sorting the remaning trains acoording to the minimum loading hours 
            z_sorted_list = sorted(
                    z, key = lambda t: t[1]
            )

            final_replace = []
            [z_sorted_list.remove(j) for i in range(len(recycled)) for j in z_sorted_list if recycled[i][0] == j[0]]
                
            final_replace.append(z_sorted_list[0])
            recycled.append(final_replace[0])

            row2 = []
            row2.append(list(row[index]))

            [cursor.execute("Update recycle set train_id = '"+str(final_replace[i][0])+"', Ir = 'R', place = '"+str(final_replace[i][1])+"' where train_id = '"+str(row2[i][0])+"'") for i in range(len(row2))]
            
            conn.commit()

            