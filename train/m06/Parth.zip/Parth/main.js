// window.onload = init;
// function init() {
//     const map = new ol.Map({
//         view: new ol.View({
//             center: [82.77112, 22.73558],
//             projection: 'EPSG:4326',
//             zoom: 4
//         }),
//         layers: [
//             new ol.layer.Tile({
//                 source: new ol.source.OSM()
//             })
//         ],
//         target: 'js-map'
//     })

//     const rail = new ol.layer.VectorImage({
//         source: new ol.source.Vector({
//             url:'libs/vectordata/rail.geojson',
//             format: new ol.format.GeoJSON()
//         }),
//         visible: true,
//         title: 'RailGeoJSON'

//     })
//     map.addLayer(rail)



//     map.on('pointermove', function(e){

//         map.addoverlay(overlayLayer)
//         map.forEachFeatureAtPixel(e.pixel,function(feature, layer){
//             let clickedCordinate = e.cordinate;
//             let clickedFeatureName = feature.get('STATION')
//             overlayLayer.setPosition(clickedCordinate);
//             overlay
//         })
//     })

//     const overlayContaierElement = document.querySelector('.overlay-container')
//     const overlayLayer = new ol.overlay({
//         element: overlayContaierElement
//     })
// }





const container = document.getElementById('popup');
const content = document.getElementById('popup-content');
const closer = document.getElementById('popup-closer');
const overlay = new ol.Overlay({
  element: container
});

closer.onclick = function () {
  overlay.setPosition(undefined);
  closer.blur();
  return false;
};

var map = new ol.Map({
  layers: [
    new ol.layer.Tile({
      source: new ol.source.OSM()
    }),
    new ol.layer.Vector({
      source: new ol.source.Vector({
        url: 'GeoObs2.json',
        format: new ol.format.GeoJSON()
      })
    })
  ],
  overlays: [overlay],
  target: 'map',
  view: new ol.View({
    center: [82.77112, 22.73558],
    projection: 'EPSG:4326',
    zoom: 4
  })
})
var feature_onHover;
map.on('pointermove', function (evt) {

  feature_onHover = map.forEachFeatureAtPixel(evt.pixel, function (feature, layers) {
    // console.log(feature);
    return feature;
  });

  if (feature_onHover) {
    var content = document.getElementById('popup-content');
    // console.log(feature_onHover.getProperties().STATION);
    

    features = [feature_onHover.getProperties().Station, feature_onHover.getProperties().IncomingTrainId, feature_onHover.getProperties().DepartingTrainId, feature_onHover.getProperties().ComingFrom, feature_onHover.getProperties().GoingTo]
    headers = ["Station: ", "Incoming-Train IDs: ", "Departing-Train IDs: ", "Coming From: ", "Going To: "]
    i = 0
    var HTML = "<table border=1 width=100%>";
    for (j = 1; j <= 5; j++) {
      if(features[i]==""){
        features[i]="-"
      }
      HTML += "<tr>" + "<th align=center>" + headers[i] + "</th>" + "<td align=center>" + features[i] + "</td>" + "</tr>";
      i++;
    }
    HTML += "</table>";
    overlay.setPosition(evt.coordinate);
    content.innerHTML = HTML

    // content.innerHTML = "Station: " + feature_onHover.getProperties().Station + "<br> Incoming-Train IDs: " + feature_onHover.getProperties().IncomingTrainId + "<br> Departing-Train IDs: " + feature_onHover.getProperties().DepartingTrainId + "<br> Coming From: " + feature_onHover.getProperties().ComingFrom + "<br> Going To: " + feature_onHover.getProperties().GoingTo;

    //  content.innerHTML = feature_onHover.getProperties().StationId;
    //  content.innerHTML = feature_onHover.getProperties().Station;
    //  'Station: ' + 
    // + '<br> Left: ' +  feature_onHover.getProperties().left 
    // + '<br> Right: ' +  feature_onHover.getProperties().right
    // + '<br> Bottom: ' +  feature_onHover.getProperties().bottom
    // + '<br> Name: ' +  feature_onHover.getProperties().Name
    // + '<br> No: ' +  feature_onHover.getProperties().No
    //   + '<br> Code: ' +  feature_onHover.getProperties().Code;

    container.style.display = 'block';
  } else {
    container.style.display = 'none';
  }
});










// new ol.layer.Vector({
//     source: new ol.source.Vector({
//       url: '/static/rail.geojson',
//       format: new ol.format.GeoJSON()
//     })
//   })


// var map = new ol.Map({
//     layers: [
//         new ol.layer.Tile({
//             source: new ol.source.OSM()
//         }),
//         new ol.layer.Vector({
//             source: new ol.source.Vector({
//                 url: '/static/rail.geojson',
//                 format: new ol.format.GeoJSON()
//             })
//         })
//     ],
//     overlays: [overlay],
//     target: 'map',
//     view: new ol.View({
//         center: [82.77112, 22.73558],
//         projection: 'EPSG:4326',
//         zoom: 4
//     })
// })