import psycopg2
import json
import pandas as pd
import csv
from collections import OrderedDict

# host='127.0.0.1', dbname= "postgres", user= "postgres", password= "postgres"

# ALTER TABLE mst_geojson_100km  
# ADD COLUMN going_to varchar;


try:
    connection = psycopg2.connect(user= "postgres",
                                  password= "postgres",
                                  host="127.0.0.1",
                                  port="5432",
                                  dbname= "postgres")
    cursor = connection.cursor()

    # Trains arriving on statiion
    query2 = "select array_agg(train_id),array_agg(detraining_station),entraning_station  from train_rpt  group by entraning_station" 
    
    # Trains deperting from statiion
    query3 = "select array_agg(train_id) ,array_agg(entraning_station),detraining_station  from train_rpt  group by detraining_station"
    
    # Station ID, name and XYcordinates
    query4 = "select Id, station, x, y, incoming_train_id, coming_from, departing_train_id, going_to from mst_geojson_100km"

    # query5 = "select train_rpt.array_agg(train_id), train_rpt.array_agg(detraining_station), train_rpt.entraning_station, mst_geojson_100km.Id, mst_geojson_100km.station, mst_geojson_100km.x, mst_geojson_100km.y  from train_rpt inner join mst_geojson_100km on mst_geojson_100km.Id= "


    # cursor.execute(query2)
    # records1 = cursor.fetchall()

    cursor.execute(query4)
    records2 = cursor.fetchall()

    # for row in records2:
    #     print("ID = ",row[0])
    #     print("Station = ",row[1])
    #     print("x = ",row[2])
    #     print("y = ",row[3])
    #     print("Incoming train id = ",row[4])
    #     print("Coming from = ",row[5])
    #     print("Departing train id = ",row[6])
    #     print("Going to = ",row[7])
    #     print('')

    # print(records2)



    




    def remove_none(nums):
        result = filter(lambda v: v is not None, nums)
        return list(result)

    finalResult=[]
    for row in records2:
        l=list(row)
        # print(l)
        result=remove_none(l)
        finalResult.append(result)
        jsonFile=json.dumps(finalResult)

    for i in jsonFile:
        with open("sample3.json", "w") as outfile:
            outfile.writelines(jsonFile)
    
    with open('sample3.json', encoding='utf-8') as inputfile:
        df = pd.read_json(inputfile)

    # headerList = ['STATION', 'CAPACITY', 'LONGITUDE', 'LATITUDE']
    df.to_csv('csvfile3.csv', header=None, encoding='utf-8', index=False)



    li = []
    with open('csvfile3.csv', 'r') as csvfile:
        reader = csv.reader(csvfile, delimiter=',')
        for STATION_ID, STATION, LATITUDE, LONGITUDE, IN_TRAIN, COMING_FROM, DEP_TRAIN, GOING_TO in reader:
            d = OrderedDict()
            d['type'] = 'Feature'
            d['geometry'] = {
                'type': 'Point',
                'coordinates': [float(LATITUDE), float(LONGITUDE)]
            }
            d['properties'] = {
                'StationId': STATION_ID,
                'Station': STATION,
                'IncomingTrainId': IN_TRAIN,
                'ComingFrom': COMING_FROM,
                'DepartingTrainId': DEP_TRAIN,
                'GoingTo':GOING_TO
            }
            li.append(d)




    d = OrderedDict()
    d['type'] = 'FeatureCollection'
    d['features'] = li
    with open('GeoObs2.json', 'w') as f:
        f.write(json.dumps(d, sort_keys=False, indent=4))





    # for row in finalResult:
    #     # print(row)
    #     d=dict(row)
    #     print(d)


    # d1=dict(finalResult)
    # print(d1)
    # jsonFile=json.dumps(d1)
    # d=dict(finalResult)
    # print(d)
    
    # for row in finalResult:
    #     print("ID = ",row[0])
    #     print("Station = ",row[1])
    #     print("x = ",row[2])
    #     print("y = ",row[3])
    #     print("Incoming train id = ",row[4])
    #     print("Coming from = ",row[5])
    #     print("Departing train id = ",row[6])
    #     print("Going to = ",row[7])
    #     print('')






    # print("Record1=====>")
    # print(records1)
    # print('')

    # for i in records1:
    #     print(i)


    # for row in records1:
    #     print("Incoming Train = ", row[0], )
    #     print("Coming From = ",row[1], )
    #     print("Station = ",row[2])
    #     print('')


    # postgres_insert_query = """ INSERT INTO mobile (ID, MODEL, PRICE) VALUES (%s,%s,%s)"""
    # record_to_insert = (listToStr, listToStr2, row[2])

    # postgres_insert_query = "INSERT INTO mst_geojson_100km (incoming_train_id, coming_from) VALUES (%s,%s) where station = %s"

    # UPDATE <table_name> SET column1 = value1, column2 = value2,….. WHERE [condition]
    # UPDATE Geeks set state=’Delhi’ where id=2;
    # Update mst_geojson_100km set incoming_train_id = %s, coming_from = %s where station = %s
    # INSERT INTO mst_geojson_100km (incoming_train_id, coming_from) VALUES (%s,%s) WHERE station = %s



# Updating table logic

    # for row in records1:
    #     # print(row)
    #     listToStr = ','.join([str(elem) for elem in row[0]])
    #     listToStr2 = ','.join([str(elem) for elem in row[1]])
    #     postgres_insert_query = "Update mst_geojson_100km set incoming_train_id = %s, coming_from = %s where station = %s"
    #     record_to_insert = (listToStr, listToStr2, row[2])
    #     cursor.execute(postgres_insert_query, record_to_insert)
    #     connection.commit()
        
# Updating table logic

    # for row in records2:
    #     # print(row)
    #     listToStr = ','.join([str(elem) for elem in row[0]])
    #     listToStr2 = ','.join([str(elem) for elem in row[1]])
    #     postgres_insert_query = "Update mst_geojson_100km set departing_train_id = %s, going_to = %s where station = %s"
    #     record_to_insert = (listToStr, listToStr2, row[2])
    #     cursor.execute(postgres_insert_query, record_to_insert)
    #     connection.commit()
            



# try2
# listToStr = ','.join([str(elem) for elem in i])

    # for row in records1:
    #     for i in row:
    #         # print(i)
    #         # print(i)
    #         for j in i:
    #             x=str(j)
    #             if x.isdigit()==True:
    #                 # print(x)
    #                 a=x
    #             # print(j)   
    #         print('')





# try1
    # for row in records1:
    #     # print(row[0])
    #     for i in row:
    #         # print(i)
    #         temp=i
    #         for i in temp:
    #             x=str(i)
    #             print(x)
    #             if x.isdigit()==True:
    #                 # print(x)
    #                 pass

    #             # print(i)
    #         print('')








    # cursor.execute(query2)
    # records1 = cursor.fetchall()
    # # print("Record1=====>")
    # # print(records1)
    # # print('')


    # cursor.execute(query2)
    # records2 = cursor.fetchall()
    # # print("Record2=====>")
    # # print(records2)
    # # print('')


    # cursor.execute(query4)
    # records3 = cursor.fetchall()
    # # print('Record3=====>')
    # # print("type---->",type(record3))
    # # print(record3)
    # # print('')


    # # print("incoming------>")
    # # for i in records1:
    # #     print(i)

    # # print("outgoing------>")
    # # for i in records2:
    # #     print(i)

    # # jsonFile=json.dumps(records1)

    # for row in records2:
    #     print('Outgoing Train = ', row[0], )
    #     print('Going To = ', row[1])
    #     print('Station = ',row[2])
    #     print('')

    # for row in records3:
    #     print("ID = ",row[0], )
    #     print("Station = ",row[1], )
    #     print("Xcordinate = ",row[2], )
    #     print("Ycordinate = ",row[3], )
    #     print('')

    # # print(exp)
    # print(records3)

    # # for i in jsonFile:
    # #     with open("sample2.json", "w") as outfile:
    # #         outfile.writelines(jsonFile) 


except (Exception, psycopg2.Error) as error:
    print("Error while fetching data from PostgreSQL", error)


finally:
    # closing database connection.
    if connection:
        cursor.close()
        connection.close()
        print("PostgreSQL connection is closed")

