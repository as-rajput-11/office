# Continuous-SpeechReco-Android
Code to continuously detect spoken language and convert to text using Google Speech Recognition
