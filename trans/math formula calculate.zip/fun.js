
//console.log("hi")

function generate() {

    clearbtnShow();   //   displaying "clear all" button

    let aValue = document.getElementById("aValue").value;
    let bValue = document.getElementById("bValue").value;
    let result = document.getElementById("demo");

    let a = parseInt(aValue);
    let b = parseInt(bValue);
    let num = a * a + 2 * a * b + b * b;

    let a_len = aValue.length;
    let b_len = bValue.length;

    if (a_len == 0 || b_len == 0) {
        contrue();
        //  if input fields is empty then showing warning
    }
    else {
        result.innerHTML = "";  //   clearr all previous answer before displaying answer
        let ans = document.createElement("p");
        let pa1 = document.createElement("p");
        let pa2 = document.createElement("p");
        let pa3 = document.createElement("p");
        let pa4 = document.createElement("p");

        let andNote = document.createTextNode("Your Result is:")
        let note1 = document.createTextNode("a2 + 2ab + b2");
        let note2 = document.createTextNode(a + "*" + a + "+" + 2 + "*" + a + "*" + b + "+" + b + "*" + b);
        let note3 = document.createTextNode(a * a + "+" + 2 * a * b + "+" + b * b);
        let note4 = document.createTextNode(num);

        ans.appendChild(andNote);
        pa1.appendChild(note1);
        pa2.appendChild(note2);
        pa3.appendChild(note3);
        pa4.appendChild(note4);

        result.appendChild(ans);
        result.appendChild(pa1);
        result.appendChild(pa2);
        result.appendChild(pa3);
        result.appendChild(pa4);
        pa4.style.color = "green"
        ans.style.color = "yellow";
        //   show answer if user input the value
    }
}

function contrue() {
    //  warning box
    let body = document.body;
    let warning = document.createElement("div");
    let notice = document.createTextNode("Please! enter your proper number in the box")
    warning.appendChild(notice);
    body.appendChild(warning);
    warning.classList.add("warning");

    setTimeout(() => {  //  this timeout for remove warning after few seconds
        warning.style.display = "none";
    }, 1200);

}

function clearall() {
    let result = document.getElementById("demo");
    result.innerHTML = "";
    //  this function for clear all previous answer
}

function clearbtnShow() {
    //  showing "clear all" button
    let clear = document.getElementById("clearAll");

    let aValue = document.getElementById("aValue").value;
    let bValue = document.getElementById("bValue").value;
    let a = parseInt(aValue);
    let b = parseInt(bValue);
    let a_len = aValue.length;
    let b_len = bValue.length;

    if (a_len == 0 || b_len == 0) {
        clear.style.display = "none";
        //  if user can`t input value then don`t show "clear all" button
    }
    else {
        clear.style.display = "inline-block";
        //  if user input some value then show "clear all" button
    }
}